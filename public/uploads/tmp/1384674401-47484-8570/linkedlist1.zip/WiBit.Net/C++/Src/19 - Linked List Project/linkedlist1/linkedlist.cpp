/*
-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
##      ## #### ########  #### ########     ##    ## ######## ########
##  ##  ##  ##  ##     ##  ##     ##        ###   ## ##          ##
##  ##  ##  ##  ##     ##  ##     ##        ####  ## ##          ##
##  ##  ##  ##  ########   ##     ##        ## ## ## ######      ##
##  ##  ##  ##  ##     ##  ##     ##        ##  #### ##          ##
##  ##  ##  ##  ##     ##  ##     ##    ### ##   ### ##          ##
 ###  ###  #### ########  ####    ##    ### ##    ## ########    ## 
Course  : Programming in C++
Filename: linkedlist.cpp
Date    : 2011/05/07
Website : http://www.wibit.net
-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
*/
#include "linkedlist.h"
linkedlist :: linkedlist()
{
  head = NULL;
  _count = 0;
}

linkedlist :: ~linkedlist()
{
  clear();
  head = NULL;
  tempPtr = NULL;
  visitPtr = NULL;
}

int linkedlist :: add(int num)
{
  if(head == NULL)
  {
    head = new node;
    head->data = num;
    head->nextLink = NULL;
    head->previousLink = NULL;
  }
  else
  {
    visitPtr = head;
    while (visitPtr->nextLink != NULL)
      visitPtr = visitPtr->nextLink;

    tempPtr = new node;
    tempPtr->data = num;
    tempPtr->nextLink = NULL;
    tempPtr->previousLink = visitPtr;
    visitPtr->nextLink = tempPtr;
  }
  _count++;
  return _count;
}

void linkedlist :: inRange(int index)
{
  if(index < 0)
    index = index + _count;
  
  if(head == NULL)
    throw new std::string("List contains no items.");
  else if(index >= _count)
    throw new std::string("Index is out of range.");
}

int linkedlist :: getAt(int index)
{
  travelToIndex(index);
  return visitPtr->data;
}

void linkedlist :: travelToIndex(int index)
{
  inRange(index);
  visitPtr = head;
  int i = 1;
  if(index != 0)
  {
    while(visitPtr->nextLink != NULL)
    {
      visitPtr = visitPtr->nextLink;
      if(i == index) break;
      i++;
    }
  }
  
  if(visitPtr == NULL)
  {
    throw new std::string("Unable to find index.");
  }
}

int linkedlist :: count() { return _count; }

void linkedlist :: removeAt(int index)
{
  if(index == 0)
  {
    tempPtr = head->nextLink;
    delete head;
    if(tempPtr != NULL)
    {
      tempPtr->previousLink = NULL;
      head = tempPtr;
    }
  }
  else
  {
    travelToIndex(index);
    tempPtr = visitPtr->previousLink;
    tempPtr->nextLink = visitPtr->nextLink;
    
    tempPtr = visitPtr->nextLink;
    if(tempPtr != NULL)
      tempPtr->previousLink = visitPtr->previousLink;
    delete visitPtr;
  }
  _count--;
}

void linkedlist :: clear()
{
  while(_count > 0)
    removeAt(0);
  head = NULL;
}

int linkedlist :: operator [] (int index)
{
  return getAt(index);
}

