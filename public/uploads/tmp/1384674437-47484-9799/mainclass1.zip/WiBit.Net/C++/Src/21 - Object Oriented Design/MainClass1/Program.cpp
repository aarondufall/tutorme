/*
-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
##      ## #### ########  #### ########     ##    ## ######## ########
##  ##  ##  ##  ##     ##  ##     ##        ###   ## ##          ##
##  ##  ##  ##  ##     ##  ##     ##        ####  ## ##          ##
##  ##  ##  ##  ########   ##     ##        ## ## ## ######      ##
##  ##  ##  ##  ##     ##  ##     ##        ##  #### ##          ##
##  ##  ##  ##  ##     ##  ##     ##    ### ##   ### ##          ##
 ###  ###  #### ########  ####    ##    ### ##    ## ########    ## 
Course  : Programming in C++
Filename: Program.cpp
Date    : 2011/05/07
Compile : g++ Program.cpp -o Program.exe
Website : http://www.wibit.net
-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
*/
#include "MainClass.cpp"

string* getArgs(int argc, const char* argv[])
{
  string* Args = new string[argc];
  for(int i = 0; i < argc; i++) Args[i] = argv[i];
  return Args;
}

int main(int argc, const char* argv[])
{
  MainClass *mainInstance = new MainClass();
  mainInstance->Main(argc, getArgs(argc, argv));
  delete mainInstance;
  return 0;
}

